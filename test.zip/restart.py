import os
import subprocess
import time

# 要关闭的进程名称和要启动的程序路径
process_name = "Arc.exe"
program_path = "C:\\Users\\49454\\AppData\\Local\\Microsoft\\WindowsApps\\Arc.exe"

def kill_process(process_name):
    try:
        # 使用taskkill命令终止进程
        subprocess.run(["taskkill", "/f", "/im", process_name], check=True)
        print(f"已终止进程: {process_name}")
    except subprocess.CalledProcessError:
        print(f"未找到正在运行的进程: {process_name}")

def start_program(program_path):
    try:
        # 启动程序
        subprocess.Popen([program_path])
        print(f"已启动程序: {program_path}")
    except Exception as e:
        print(f"启动程序时出错: {e}")

if __name__ == "__main__":
    kill_process(process_name)
    # 等待几秒钟以确保进程完全终止
    time.sleep(1)
    start_program(program_path)